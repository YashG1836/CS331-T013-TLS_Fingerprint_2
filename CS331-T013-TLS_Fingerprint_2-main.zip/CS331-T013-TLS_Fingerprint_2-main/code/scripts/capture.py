"""Make one capture from captures/manifest.json.

Run inside the lab container:  python3 code/scripts/capture.py <capture_id>
Starts tcpdump, runs the client command, stops tcpdump. All settings come from the manifest.
"""
import json
import os
import subprocess
import sys
import time

MANIFEST = "captures/manifest.json"


def load_manifest():
    with open(MANIFEST) as f:
        return json.load(f)


def find_capture(manifest, capture_id):
    for cap in manifest["captures"]:
        if cap["id"] == capture_id:
            return cap
    sys.exit("no capture with id: " + capture_id)


def run_all(commands, settings, env=None):
    for cmd in commands:
        cmd = cmd.format(**settings)  # fills {chromium}, {interface}, ... from settings
        print("+", cmd)
        subprocess.run(cmd, shell=True, env=env)


def main():
    if len(sys.argv) != 2:
        sys.exit("usage: capture.py <capture_id>")

    manifest = load_manifest()
    settings = manifest["settings"]
    cap = find_capture(manifest, sys.argv[1])

    pcap = settings["pcap_dir"] + "/" + cap["id"] + ".pcap"
    env = dict(os.environ)
    if cap.get("keylog"):
        os.makedirs(settings["keylog_dir"], exist_ok=True)
        env["SSLKEYLOGFILE"] = settings["keylog_dir"] + "/" + cap["id"] + ".keylog"

    run_all(cap.get("setup", []), settings)
    tcpdump = subprocess.Popen(["tcpdump", "-i", settings["interface"], "-U", "-w", pcap, cap["filter"]])
    time.sleep(settings["wait_seconds"])

    for i in range(cap.get("repeat", 1)):
        run_all([cap["command"]], settings, env)

    time.sleep(settings["wait_seconds"])
    tcpdump.terminate()
    tcpdump.wait()
    print("saved", pcap)


if __name__ == "__main__":
    main()
