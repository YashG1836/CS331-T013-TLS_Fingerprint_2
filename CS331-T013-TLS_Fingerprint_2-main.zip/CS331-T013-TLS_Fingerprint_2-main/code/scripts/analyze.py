"""Run the real tools on every capture and write the results.

Run inside the lab container:  python3 code/scripts/analyze.py
Tools used (we do not compute any fingerprint ourselves):
  tshark     - Wireshark, written in C
  ja4        - FoxIO JA4+ CLI, written in Rust
Writes results/raw/<id>.*  (raw tool output), results/summary.json and results/summary.md
"""
import json
import os
import subprocess
import time

MANIFEST = "captures/manifest.json"

# what we ask tshark for, for every ClientHello / ServerHello
HELLO_FIELDS = [
    "frame.number",
    "tls.handshake.extensions_server_name",
    "tls.handshake.ja3",
    "tls.handshake.ja4",
    "tls.handshake.length",
    "tcp.segment.count",
    "quic.crypto.fragment.count",
    "tls.ech.client_hello_type",
]
SERVER_FIELDS = ["frame.number", "tls.handshake.extensions_key_share_group"]

# columns shown in results/summary.md
TABLE_COLUMNS = [
    "id", "limitation", "hellos_tshark", "hellos_ja4", "distinct_ja3", "distinct_ja4",
    "distinct_ja4_main", "tools_agree", "ja4x_ja4h_no_keys", "ja4x_ja4h_with_keys", "hello_bytes_max",
    "pieces_max", "biggest_frame", "groups_chosen", "ech_ext_hellos", "seconds_tshark", "seconds_ja4",
]


def run(cmd):
    """Run a command, return (stdout, seconds taken)."""
    start = time.time()
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    return out, round(time.time() - start, 3)


def tshark(pcap, display_filter, fields, keylog=None):
    cmd = ["tshark", "-r", pcap, "-Y", display_filter, "-T", "fields"]
    if keylog:
        cmd += ["-o", "tls.keylog_file:" + keylog]
    for field in fields:
        cmd += ["-e", field]
    out, seconds = run(cmd)
    rows = [dict(zip(fields, line.split("\t"))) for line in out.splitlines()]
    return rows, seconds


def foxio_ja4(pcap, keylog=None, program="ja4"):
    cmd = [program, "--json", "--with-raw", pcap]
    if keylog:
        cmd += ["--keylog-file", keylog]
    out, seconds = run(cmd)
    streams = [json.loads(line) for line in out.splitlines() if line.startswith("{")]
    return streams, seconds


def numbers(values):
    """'1517,1460' style tshark values -> list of ints (empty values skipped)."""
    result = []
    for value in values:
        for part in value.split(","):
            if part.strip().isdigit():
                result.append(int(part))
    return result


def count_ja4x_ja4h(streams):
    # ja4 puts these inside nested lists ("tls_certs", "http"), so search the whole text
    text = json.dumps(streams)
    return text.count('"ja4x"') + text.count('"ja4h"')


def analyze_one(cap, settings):
    pcap = settings["pcap_dir"] + "/" + cap["id"] + ".pcap"
    keylog = settings["keylog_dir"] + "/" + cap["id"] + ".keylog"
    has_keys = cap.get("keylog") and os.path.exists(keylog)

    hellos, seconds_tshark = tshark(pcap, "tls.handshake.type == 1", HELLO_FIELDS)
    servers, _ = tshark(pcap, "tls.handshake.type == 2", SERVER_FIELDS)
    frames, _ = tshark(pcap, "frame", ["frame.len"])
    dns, _ = tshark(pcap, "dns.flags.response == 0", ["dns.qry.name"])
    streams, seconds_ja4 = foxio_ja4(pcap)
    main_streams, _ = foxio_ja4(pcap, program="ja4-main")  # unreleased FoxIO fix, for comparison

    ja4_tshark = set(h["tls.handshake.ja4"] for h in hellos if h["tls.handshake.ja4"])
    ja4_foxio = set(s["ja4"] for s in streams if "ja4" in s)
    pieces = numbers([h["tcp.segment.count"] for h in hellos] + [h["quic.crypto.fragment.count"] for h in hellos])

    row = {
        "id": cap["id"],
        "limitation": cap["limitation"],
        "hellos_tshark": len(hellos),
        "hellos_ja4": sum(1 for s in streams if "ja4" in s),
        "distinct_ja3": len(set(h["tls.handshake.ja3"] for h in hellos if h["tls.handshake.ja3"])),
        "distinct_ja4": len(ja4_tshark),
        "distinct_ja4_main": len(set(s["ja4"] for s in main_streams if "ja4" in s)),
        "tools_agree": ja4_tshark == ja4_foxio,
        "ja4x_ja4h_no_keys": count_ja4x_ja4h(streams),
        "ja4x_ja4h_with_keys": "-",
        "hello_bytes_max": max(numbers([h["tls.handshake.length"] for h in hellos]), default=0),
        "pieces_max": max(pieces, default=1),
        "biggest_frame": max(numbers([f["frame.len"] for f in frames]), default=0),
        "groups_chosen": sorted(set(numbers([s["tls.handshake.extensions_key_share_group"] for s in servers]))),
        "ech_ext_hellos": sum(1 for h in hellos if h["tls.ech.client_hello_type"] != ""),
        "server_names": sorted(set(h["tls.handshake.extensions_server_name"] for h in hellos)),
        "dns_names": sorted(set(d["dns.qry.name"] for d in dns)),
        "ja4_tshark": sorted(ja4_tshark),
        "ja4_foxio": sorted(ja4_foxio),
        "ja4_main": sorted(set(s["ja4"] for s in main_streams if "ja4" in s)),
        "ja4s_foxio": sorted(set(s["ja4s"] for s in streams if "ja4s" in s)),
        "seconds_tshark": seconds_tshark,
        "seconds_ja4": seconds_ja4,
    }

    raw = {"tshark_client_hellos": hellos, "tshark_server_hellos": servers, "foxio_ja4": streams}
    if has_keys:
        keyed_streams, _ = foxio_ja4(pcap, keylog)
        row["ja4x_ja4h_with_keys"] = count_ja4x_ja4h(keyed_streams)
        raw["foxio_ja4_with_keys"] = keyed_streams
    return row, raw


def write_table(rows, path):
    lines = ["| " + " | ".join(TABLE_COLUMNS) + " |", "|" + "---|" * len(TABLE_COLUMNS)]
    for row in rows:
        lines.append("| " + " | ".join(str(row[c]) for c in TABLE_COLUMNS) + " |")
    with open(path, "w") as f:
        f.write("# Results (generated by code/scripts/analyze.py — do not edit by hand)\n\n")
        f.write("\n".join(lines) + "\n")


def main():
    with open(MANIFEST) as f:
        manifest = json.load(f)
    settings = manifest["settings"]
    out_dir = settings["results_dir"]
    os.makedirs(out_dir + "/raw", exist_ok=True)

    rows = []
    for cap in manifest["captures"]:
        if not os.path.exists(settings["pcap_dir"] + "/" + cap["id"] + ".pcap"):
            print("missing capture, skipped:", cap["id"])
            continue
        row, raw = analyze_one(cap, settings)
        rows.append(row)
        with open(out_dir + "/raw/" + cap["id"] + ".json", "w") as f:
            json.dump(raw, f, indent=1)
        print("done:", cap["id"])

    with open(out_dir + "/summary.json", "w") as f:
        json.dump(rows, f, indent=1)
    write_table(rows, out_dir + "/summary.md")


if __name__ == "__main__":
    main()
