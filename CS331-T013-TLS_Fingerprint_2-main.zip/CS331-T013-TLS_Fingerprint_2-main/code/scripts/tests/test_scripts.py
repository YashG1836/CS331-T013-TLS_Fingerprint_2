"""Small checks for the manifest and the helper in analyze.py.
Run from the project root:  python3 -m pytest -q code/scripts/tests
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from analyze import numbers  # noqa: E402

MANIFEST = "captures/manifest.json"
NEEDED_KEYS = ["id", "limitation", "what", "command", "filter"]


def load():
    with open(MANIFEST) as f:
        return json.load(f)


def test_ids_are_unique():
    ids = [cap["id"] for cap in load()["captures"]]
    assert len(ids) == len(set(ids))


def test_every_capture_has_needed_keys():
    for cap in load()["captures"]:
        for key in NEEDED_KEYS:
            assert key in cap, cap.get("id", "?") + " is missing " + key


def test_placeholders_are_known():
    manifest = load()
    for cap in manifest["captures"]:
        for cmd in [cap["command"]] + cap.get("setup", []):
            cmd.format(**manifest["settings"])  # raises KeyError on an unknown {name}


def test_numbers():
    assert numbers(["1517,1460", "", "x", "3"]) == [1517, 1460, 3]
    assert numbers([]) == []
