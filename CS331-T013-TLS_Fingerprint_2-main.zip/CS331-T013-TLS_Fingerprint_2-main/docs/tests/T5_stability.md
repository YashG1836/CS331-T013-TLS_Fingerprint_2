# T5: Is one client = one fingerprint? (L5)

**One line:** open many fresh connections from the same client and count how many different fingerprints come out; do the same for two apps that share one TLS library.

## What is being done
- Chromium 156: 10 page loads, giving **50 ClientHellos** (the page plus Chromium's own background connections).
- curl: **10** connections. Python `urllib`: **10** connections. Both use the same OpenSSL 3.5.7.
- We count distinct JA3 and JA4 per client, with:
  - **released** tools: FoxIO v0.18.6 and tshark 4.4.19
  - FoxIO's **unreleased** `main` (commit c6469a7), built as `ja4-main`

## What is being tested
1. **Stability:** does the same client always get the same fingerprint?
2. **Collision:** do two apps on the same library get the same fingerprint?

## Why
- Sir: *"the same application cannot have different hash? … it can"*, and *"will it work tomorrow?"*.
- A blocklist (sir's example: block Firefox, allow Chrome) only works if one client = one fingerprint.
- Phase 1 bug: our detector flagged **real Chrome** as fake because JA3 changed. Chrome shuffles extensions (RFC 8446 §4.1.2 allows any order).
- GREASE (RFC 8701) = random reserved values that clients insert; fingerprints must ignore them.

## Control / what stays the same
Same machine, same server, fresh browser profile each time; curl and Python are the "simple client" controls.

## Commands
```sh
make capture IDS="tls_chromium_repeat tls_curl_repeat tls_python_repeat"
make eval
# extra check with the newest Wireshark on the Mac:
tshark -r captures/pcaps/tls_chromium_repeat.pcap -Y "tls.handshake.type==1" -T fields -e tls.handshake.ja4 | sort -u | wc -l
# how many different first signature algorithms (GREASE values) Chromium used -> 15:
tshark -r captures/pcaps/tls_chromium_repeat.pcap -Y "tls.handshake.type==1" -T fields -e tls.handshake.ja4_r | cut -d_ -f4 | cut -d, -f1 | sort -u | wc -l
```

## Expected
JA3: many values for Chromium (shuffling). JA4: 1 value per client (it sorts).

## What we saw
| client | hellos | distinct JA3 | distinct JA4 (released tools) | distinct JA4 (`ja4-main`) |
|---|---|---|---|---|
| Chromium 156 | 50 | **50** | **15** | **1** |
| curl | 10 | 1 | 1 | 1 |
| Python | 10 | 1 | 1 | 1 |

- tshark 4.6.8 (newest stable, on the Mac) on the same pcap: also **15**.
- **Why 15:** Chromium puts a random GREASE value **first in `signature_algorithms`**. We saw 15 different GREASE values across the 50 hellos, one per JA4.
  - FoxIO's spec says "ignore GREASE values anywhere".
  - But the released code (`sig_hash_algs()` in `rust/ja4/src/tls.rs`, v0.18.6 to v0.18.8) and Wireshark 4.4 don't filter it there.
  - Only unreleased FoxIO `main` and Wireshark `master` fix it.
- **Collision:** curl and Python share **JA4 part b** (`1d37bd780c83`, the cipher list from OpenSSL), but differ in parts a and c (HTTP/2 vs HTTP/1.1, 13 vs 14 extensions). So they partly collide, not fully.

## What it means
- JA3 is useless for Chromium: every connection is new.
- With today's **released** tools, JA4 splits one browser into **up to 16** identities (16 GREASE values), so any list built on JA4 misses most Chromium connections.
- Phase 1's documented Chrome JA4 (`…_541cd5a3d78e`) is one of these 15, so Phase 1 had seen the symptom.

## What it does NOT prove
- One Chromium version, one OS. Firefox not tested.
- The fix exists upstream, so this is a **deployment gap** (released vs unreleased), not a new discovery.
