# T0: Lab and script checks

**One line:** before trusting any result, check the lab, the scripts and the teammates' C++ code actually work.

## What is being done
1. Build the teammates' C++ QUIC code (branch `arena/0d29f32c`) on Linux and run its tests, normal and with memory checkers (AddressSanitizer + UndefinedBehaviorSanitizer).
2. Run our 4 small Python tests (`code/scripts/tests/test_scripts.py`).
3. Record the exact version of every tool (`results/versions.txt`).

## What is being tested
- The C++ code builds on Linux and passes its own tests, including the RFC 9001 Appendix A test vectors.
- Our manifest is valid:
  - no duplicate test IDs
  - every test has its needed fields
  - every `{placeholder}` in a command exists in `settings`
- The helper that reads tshark's comma-separated numbers is correct.

## Why
- The plan's first gate (Implementation.md §8, Tue 3 Nov): "build/test the current checkpoint" before anything else. Suhani asked for it to run on Linux.
- Phase 1 lesson: a result is only as good as the setup. A broken manifest would silently skip a test.
- Versions matter: a different ja4 or tshark version can give a different answer (see T5).

## Commands
```sh
make test                         # our 4 python tests
cat results/checkpoint_build_test.txt   # C++ build + test log
cat results/versions.txt
```

## Result
- C++: builds; CTest **1/1 passed**; the team's pytest **9/9 passed**; sanitizer build **1/1 passed**.
- Our tests: **4/4 passed**.
- Tool facts found while doing this:
  - FoxIO tag **v0.18.6 reports itself as "0.18.5"** (the version wasn't bumped in `rust/Cargo.toml`). Always record the tag/commit.
  - FoxIO ja4 uses **tshark to parse packets** (`rtshark` library), so the two tools share one parser.
  - tshark 4.4.19 has **no JA4S**; FoxIO's CLI has **no JA4T**.

## What it does NOT prove
- The C++ tests pass on RFC test vectors, not yet on our real captures (that's Track 2).
