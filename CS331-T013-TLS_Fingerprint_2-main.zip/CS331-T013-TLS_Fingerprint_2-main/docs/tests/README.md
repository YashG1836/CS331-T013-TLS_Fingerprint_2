# Our tests: index

Phase 1 problem: tests looked random (one capture per client, no clear question). This time **every test answers one question and changes only one thing.**

## How every test is built
1. **Question:** one sentence, written *before* capturing.
2. **One variable changes:** everything else stays the same (same client, same server, same tools).
3. **Control:** the "normal" case next to the changed case, so a difference means something.
4. **Real tools only:** tshark (Wireshark, C) and FoxIO ja4 (Rust) read the capture. We don't compute fingerprints.
5. **Numbers come from `results/summary.md`**, which `make eval` regenerates. Nothing is typed by hand.
6. **Each file says what the test does NOT prove.**

## The tests

| File | Question in one line | Changed variable | Result |
|---|---|---|---|
| [T0_lab_checks.md](T0_lab_checks.md) | Can we trust our lab and scripts? | - | passed |
| [T1_quic.md](T1_quic.md) | Can the real tools fingerprint QUIC? | TCP → QUIC, two clients | yes, hypothesis wrong |
| [T2_keys.md](T2_keys.md) | Which fingerprints work without TLS keys? | keys given / not given | JA4X/JA4H need keys |
| [T3_vantage_offload.md](T3_vantage_offload.md) | Does *where/how* we capture change what we see? | offload on / off | yes (packets, TCP values) |
| [T4_post_quantum.md](T4_post_quantum.md) | What does a post-quantum key share change? | PQ group on / off | size ×3, JA4 changes |
| [T5_stability.md](T5_stability.md) | Is one client = one fingerprint? | same client, 10 repeats | Chromium: 15 JA4s |
| [T6_ipv6.md](T6_ipv6.md) | Does IPv6 change the fingerprint? | IPv4 / IPv6 | not measured (no IPv6) |
| [T7_ech_dns.md](T7_ech_dns.md) | What hides the website name: ECH, DNS? | ECH off / on / + DoH | ECH hides SNI, DNS leaks it |

Not a test: **L8 certificate abridging**. It isn't deployed, so there's nothing real to capture (see LEDGER.md).

## Run them
```sh
make image                          # once
make capture IDS="tls_pq_on tls_pq_off"   # re-make one test's captures (needs internet)
make eval                           # recompute every number from the committed pcaps (no internet needed)
```
