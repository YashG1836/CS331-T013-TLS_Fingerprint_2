# Presentation guide: what to show, in what order

About 12 minutes plus questions. For every step, say: the question, what we changed, one number, the RFC reason, and what it does NOT prove.
Every number we say must be in `results/` or come from a command written in the test file (`docs/tests/`).

## Before the viva (the night before)
- [ ] `make image` already built (takes ~10 min, so never during the viva).
- [ ] `make eval` and `make test` run once, all fine. `make eval` needs **no internet**, because the pcaps are committed.
- [ ] Tabs open: `PHASES.md`, `captures/manifest.json`, `results/summary.md`, `LEDGER.md`, `docs/tests/T5_stability.md`.
- [ ] Wireshark open with `captures/pcaps/tls_chromium_repeat.pcap`.
- [ ] Each of us has read `VIVA_QUESTIONS.md` and can answer **without looking**.
- [ ] Decide who presents which step (P1–P4 below; fill in real names).

---

## Step 1: What went wrong in Phase 1, what changed (1 min) (P_)
**Show:** `PHASES.md`, top half.
**Say:**
- Phase 1 wrote its own JA3/JA4 in Python, with fake 2-packet captures and no RFC reasoning.
- Phase 2 does what sir asked: take the tools people actually use and find where they break.
**Likely question:** "Why not Python/C this time?" → VIVA Q15, Q16.

## Step 2: What a fingerprint is, and where the fields come from (1.5 min) (P_)
**Show:** a ClientHello in Wireshark (any pcap); expand cipher suites, extensions, signature algorithms.
**Say:**
- The ClientHello is plaintext because no keys exist yet (RFC 8446 §2).
- Each field and its RFC: ciphers/extensions RFC 8446 §4.1.2, SNI RFC 6066 §3, GREASE RFC 8701.
- JA4 = `a_b_c`: readable part a, sorted-cipher hash b, sorted-extensions + sig-algs hash c.
**Likely questions:** VIVA Q2, Q3, Q6–Q9.

## Step 3: How we test (1.5 min) (P_)
**Show:** `code/Dockerfile`, then `captures/manifest.json` (one entry), then `docs/tests/README.md`.
**Say:**
- The Linux lab is a Docker container: FoxIO ja4 (Rust) built from the release tag, tshark (C), Chromium, curl, tcpdump.
- Every test is one manifest entry: one question, **one variable changed**, a control next to it.
- Our code only *runs* the tools (`capture.py` 62 lines, `analyze.py` 163 lines); we compute no fingerprint ourselves.
**Likely question:** "How do you know the tools are right?" → VIVA Q17. Say: both tools agree, but FoxIO parses using tshark, so they're not fully independent.

## Step 4: Live: regenerate every number (1 min) (P_)
**Run:**
```sh
make eval
cat results/summary.md
```
**Say:** "Every number in our slides comes from this table, generated from the committed pcaps. Nothing is typed by hand." (Phase 1's report had hashes that didn't match its pcaps.)

## Step 5: Results (4–5 min) (P_ / P_)
One test per bullet. Open its `docs/tests/T*.md` if asked for details.

1. **T5, stability:** Chromium gives 50 JA3 and **15 JA4** in 50 hellos with released FoxIO **and** Wireshark; unreleased FoxIO main gives **1**.
   **Show live:** in Wireshark, open 2 ClientHellos and point at the first signature algorithm (`0x4a4a`, `0xdada` …, a different GREASE value). FoxIO's spec says ignore GREASE anywhere; the released code doesn't.
2. **T3, vantage/offload:** the same ClientHello shows as 1 frame of 1586 bytes (bigger than the MTU) or 2 frames, depending only on an offload switch. The "server" SYN-ACK has MSS 65495, which is Docker's proxy, not Cloudflare.
   *Sir's GRO/LSO point, measured.*
3. **T4, post-quantum:** hello 508 → 1511 bytes, group 4588 proven from the ServerHello. JA4 changed even though it has no group field (padding / point-format side effects).
4. **T2, keys:** JA4X/JA4H: 0 without keys, 5 with keys. On TLS 1.3 they don't exist for a passive tap.
5. **T7, ECH/DNS:** ECH hides the name in SNI (`cloudflare-ech.com`, page says `sni=encrypted`), but plain DNS still shows `crypto.cloudflare.com`. Encrypted DNS is blocked on the campus network.
6. **T1, QUIC (negative result):** we expected the tools to fail; they didn't. 5/5 hellos even with Chromium's 21 CRYPTO fragments. Say clearly that our guess was wrong; that is a result too.
7. **T6, IPv6:** not measured, because our network has no IPv6. Say it plainly; don't guess.

## Step 6: Tool facts we discovered (30 s) (P_)
- FoxIO tag v0.18.6 reports "0.18.5".
- tshark has no JA4S; FoxIO's CLI has no JA4T.
- FoxIO depends on tshark for parsing.

## Step 7: What's next / our contribution (1 min) (P_)
**Show:** the end of `LEDGER.md` (candidate table).
**Say:**
- The GREASE bug is already fixed upstream (unreleased), so we won't claim it as ours. Our value there is measuring the impact.
- Contribution options on top of the existing Rust tool: add JA4T/JA4TS to FoxIO's CLI with a proxy/MSS sanity warning, **or** QUIC connection migration (Track 2).
- Open: IPv6 run, QUIC partial-capture/migration tests.

## Step 8: How we used AI (30 s) (P_)
- Raw prompts in `ai/prompts.txt`, unedited.
- `DECISIONS.md` written by us.
- Each test file has a "what it does NOT prove" section.

---

## If something breaks during the demo
| Problem | Do this |
|---|---|
| Docker not starting | Show `results/summary.md` (already generated) and run tshark on the Mac: `tshark -r captures/pcaps/tls_chromium_repeat.pcap -Y "tls.handshake.type==1" -T fields -e tls.handshake.ja4 \| sort -u \| wc -l` → 15 |
| No internet | Don't run `make capture`; `make eval` works offline |
| Sir asks for a new capture live | `make capture IDS=tls_curl_repeat && make eval` (~30 s, needs internet) |

## Don't say
- "QUIC can't be fingerprinted" (T1 shows it can).
- "JA4 identifies the user/app" (it identifies a TLS library + config).
- Any IPv6 or certificate-abridging result (none measured).
- "We found a new bug" about GREASE (upstream already fixed it on main; it's unreleased).
