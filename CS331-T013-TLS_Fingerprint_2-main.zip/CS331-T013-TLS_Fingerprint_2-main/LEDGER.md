# Limitation ledger (status of all limitations)

One line per limitation. The full details (what we did, why, commands, numbers, what it does NOT prove) are in the linked test file, so the numbers are written in only one place.
All numbers come from `results/summary.md` (`make eval`) or from a command written in the test file.

| ID | Limitation | Test | Status | Main number |
|---|---|---|---|---|
| L1 | QUIC: can real tools fingerprint it? | [T1](docs/tests/T1_quic.md) | Our guess was wrong: they can | 5/5 hellos read by both tools, even when split into 21 pieces |
| L2 | Certificate/HTTP fingerprints need TLS keys | [T2](docs/tests/T2_keys.md) | Confirmed | JA4X+JA4H: 0 without keys, 5 with keys |
| L3 | Where/how you capture changes what you see | [T3](docs/tests/T3_vantage_offload.md) | Confirmed | same hello = 1 frame (1586 B) or 2 frames; "server" MSS 65495 came from Docker's proxy |
| L4 | Post-quantum key share changes size and JA4 | [T4](docs/tests/T4_post_quantum.md) | Confirmed | hello 508 → 1511 bytes; JA4 12 vs 14 extensions |
| L5 | One browser, many JA4s (released tools) | [T5](docs/tests/T5_stability.md) | Confirmed | Chromium: 15 JA4s in 50 hellos; unreleased FoxIO: 1 |
| L6 | IPv4 vs IPv6 | [T6](docs/tests/T6_ipv6.md) | Not measured (no IPv6 on our network) | - |
| L7 | ECH hides the name, DNS still shows it | [T7](docs/tests/T7_ech_dns.md) | Confirmed (DoH blocked here) | SNI `cloudflare-ech.com`, but DNS asked for `crypto.cloudflare.com` |
| L8 | Certificate compression / abridged certificates | none | Only mentioned: not deployed, nothing to capture | - |

## Facts about the tools (found in T0, they affect all rows)
- FoxIO tag v0.18.6 reports `ja4 0.18.5` (`rust/Cargo.toml` was not updated).
- FoxIO ja4 reads packets through tshark (`rtshark` in `rust/ja4/Cargo.toml`). So when the two tools agree, that is two JA4 calculators on one packet parser.
- tshark 4.4.19 has no JA4S. FoxIO's Rust tool has no JA4T; in FoxIO's repo JA4T is only in the Zeek script `zeek/ja4t/main.zeek`.

## Lab setup (applies to every test)
- Docker Linux container on a MacBook (aarch64), campus network. Versions: `results/versions.txt`.
- Captures are taken on `eth0` inside the container, behind Docker Desktop's network layer (see T3).

## What we could improve on top of the existing tools (team decides on Thu 5 Nov)
| # | Problem | Idea | Where | Is it new? |
|---|---|---|---|---|
| 1 | L5: GREASE left in signature algorithms | Measure the effect on released versions (done: 15 → 1) | FoxIO (Rust), Wireshark (C) | No. Already fixed in their unreleased code. |
| 2 | No JA4T/JA4TS in FoxIO's tool; TCP values can come from a proxy (L3) | Add JA4T/JA4TS to FoxIO's Rust tool, plus a warning when SYN values are impossible (e.g. MSS bigger than the MTU allows) | FoxIO (Rust) | Need to check nobody did it yet. FoxIO's licence allows academic use. |
| 3 | L1 open part: QUIC connection migration | Measure what a capture sees after migration (Track 2) | tshark / C++ | Need to check |
| 4 | L7: name leaks through DNS when ECH is on | Per connection, list where the site name is still visible (SNI / DNS) | tshark fields | It's an analysis, not a tool |
