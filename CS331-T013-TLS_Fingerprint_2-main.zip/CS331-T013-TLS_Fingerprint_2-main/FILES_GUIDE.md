# Files guide: what we're doing, and what every file is for

## What we're doing (big picture, simple)
1. **TLS fingerprinting:** a website's traffic is encrypted, but the *first* message a client sends (the ClientHello) is not. Every app/library fills it a little differently, so its "shape" works like a fingerprint (JA3, JA4…). Firewalls use this to recognise or block apps without decrypting anything.
2. **Phase 1 mistake:** we wrote our own fingerprint code in Python and tested it on fake captures.
3. **Phase 2 (sir's direction):** don't rebuild it. Take the tools the industry really uses, **Wireshark/tshark (C)** and **FoxIO ja4 (Rust)**, and find **where they stop working** in real conditions: QUIC, keys, capture point, post-quantum, repeat connections, IPv6, ECH/DNS.
4. For each problem: a real capture, one command, a number, and the RFC reason. Then the team picks 1–2 problems to improve **on top of** those tools.
5. **Track 1** (done now) = tools + captures + evidence. **Track 2** (next) = QUIC deep dive.

## Flow
```
captures/manifest.json ──► capture.py ──► captures/pcaps/*.pcap ──► analyze.py ──► results/summary.md
   (what to test)          (tcpdump +        (real traffic)        (runs tshark     (numbers we quote)
                            client)                                  + ja4)
```

## Every file

### Top level
| File | What it does | Why we need it |
|---|---|---|
| `README.md` | Front page: the idea in 5 lines, reading order, folder structure, how to run | First thing sir/TA opens |
| `GLOSSARY.md` | Every term used in the repo, in simple words | So someone with zero background can follow |
| `PHASES.md` | Phase 1 vs Phase 2 plan vs what Phase 2 did | Shows we learned from Phase 1's mistakes |
| `LEDGER.md` | One-page status of all limitations, tool facts, ideas for what to improve | The summary of Track 1; details stay in `docs/tests/` so numbers are written once |
| `docs/tests/` | One file per test (T0–T7): what is done, what is tested, why, result, what it does NOT prove | Phase 1 tests looked random; these make every test's purpose clear |
| `PRESENTATION_GUIDE.md` | Step-by-step script for the presentation and demo | So any of us can present in a fixed order without mistakes |
| `VIVA_QUESTIONS.md` | Questions sir asked or may ask, with short answers | Phase 1 viva went badly on basics |
| `FILES_GUIDE.md` | This file | So everyone knows what each file is |
| `Implementation.md` | Team's full implementation plan (long) | The plan we're following; read only for background |
| `Sameer sir meet_original.txt` | Transcript of our meeting with sir | Source of sir's direction (UTF-16 file) |
| `Makefile` | Short commands: `make image / capture / eval / test` | One command per step, the same for everyone |
| `.gitignore` | Keeps `Phase1/`, key logs and caches out of git | Phase 1 is only reference; keys are sensitive |

### `code/`
| File | What it does | Why we need it |
|---|---|---|
| `code/Dockerfile` | Builds the Linux lab: FoxIO ja4 (release tag v0.18.6 + unreleased `main` as `ja4-main`), tshark, Chromium, curl, tcpdump, OpenSSL | The plan says run on Linux; same versions for everyone, so results repeat |
| `code/scripts/capture.py` | Reads one test from the manifest, starts tcpdump, runs the client command N times, stops tcpdump | Makes real captures the same way every time |
| `code/scripts/analyze.py` | Runs tshark and ja4 on every pcap, counts hellos / distinct fingerprints / sizes / groups, writes `results/` | Every number comes from the real tools, not from us |
| `code/scripts/versions.sh` | Prints the exact version of every tool | Results depend on versions (see T5) |
| `code/scripts/tests/test_scripts.py` | 4 small checks: manifest IDs unique, fields present, placeholders valid, number parser correct | A broken manifest would silently skip a test |

### `captures/`
| File | What it does | Why we need it |
|---|---|---|
| `captures/manifest.json` | **The list of all tests**: id, limitation, what, command, capture filter, repeats, setup. Settings (interface, MTU, Chromium flags) are at the top | No hard-coding in code; to add a test you add one entry |
| `captures/pcaps/*.pcap` | The 15 real captures | The evidence; anyone can re-check them |
| `captures/config/ech_off_policy.json` | Chrome policy that turns ECH off | Needed for T7 (the normal flag didn't work in Chromium 156) |
| `captures/config/doh_policy.json` | Chrome policy for DNS-over-HTTPS | Needed for T7's encrypted-DNS run |
| `captures/keylogs/` | TLS session keys from T2 (git-ignored) | Needed to show JA4X/JA4H only appear with keys |

### `results/` (generated, never edit by hand)
| File | What it does |
|---|---|
| `results/summary.md` | The results table we quote |
| `results/summary.json` | Same plus details (JA4 strings, server names, DNS names) |
| `results/raw/<test>.json` | Full raw output of tshark and ja4 per capture |
| `results/versions.txt` | Exact tool versions used |
| `results/capture_log.txt` | What `make capture` ran |
| `results/checkpoint_build_test.txt` | Build + test log of the teammates' C++ QUIC code on Linux |
| `results/tls_ech_*_page.txt` | Cloudflare's own `sni=plaintext/encrypted` answer for T7 |

### `ai/`
| File | What it does | Why we need it |
|---|---|---|
| `ai/prompts.txt` | Every prompt we gave the AI, copied exactly, typos included | Course requirement; we lost 2 marks in Phase 1 over this |

### Not in this folder
| What | Where | Note |
|---|---|---|
| Teammates' C++ QUIC extractor | branch `arena/0d29f32c-cs331-phase2` of the team repo | For Track 2; built and tested on Linux in T0 |
| `DECISIONS.md`, `WHO_KNOWS_WHAT.md` | to be written **by us** | The plan says AI must not write these |
