# CN Project 2: where do real TLS fingerprinting tools stop working?

Team T013, CS331 Computer Networks.

## The idea in 5 lines
1. Web traffic is encrypted, but the first message of every connection (the **ClientHello**) is not.
2. Each app fills that message a bit differently, so it works like a **fingerprint** (JA3, JA4). Networks use it to recognise or block apps without decrypting anything.
3. In Phase 1 we wrote our own fingerprint code. Our professor said: don't rebuild it; take the tools people really use and find **where they break**.
4. So we took **Wireshark/tshark** (C) and **FoxIO ja4** (Rust), made **real captures** in different situations (QUIC, no keys, post-quantum, ECH…), and measured where the fingerprints fail.
5. Each situation is one test, explained in its own file, with numbers that one command regenerates.

## Read in this order (new to all this? start at 1)
| # | File | What you get |
|---|---|---|
| 1 | [GLOSSARY.md](GLOSSARY.md) | every term (RFC, TLS, QUIC, JA4, MTU, …) in simple words |
| 2 | [FILES_GUIDE.md](FILES_GUIDE.md) | what every file in this repo is and why it exists |
| 3 | [PHASES.md](PHASES.md) | Phase 1 vs Phase 2: what we did, what went wrong, what changed |
| 4 | [docs/tests/README.md](docs/tests/README.md) | the tests, one file each: what, why, result, limits |
| 5 | [LEDGER.md](LEDGER.md) | one-page status of all limitations + what we could improve |
| 6 | [VIVA_QUESTIONS.md](VIVA_QUESTIONS.md) | questions sir asked or may ask, with short answers |
| 7 | [PRESENTATION_GUIDE.md](PRESENTATION_GUIDE.md) | step-by-step presentation and live demo |

Background (long, only if needed): [Implementation.md](Implementation.md) (team's full plan) and `Sameer sir meet_original.txt` (meeting transcript, UTF-16 text).

## Folder structure
```
captures/manifest.json   list of all tests (what to run, what to capture)
captures/pcaps/          the real captures (evidence)
code/Dockerfile          the Linux lab with all tools
code/scripts/            capture.py (make a capture), analyze.py (run tshark + ja4), tests
results/                 generated numbers; never edited by hand
docs/tests/              one explanation file per test
ai/prompts.txt           every prompt we gave the AI, unedited
```

## Run it (needs Docker)
```sh
make image      # build the Linux lab once (~10 min)
make capture    # make all captures again (needs internet)
make eval       # run tshark + ja4 on all pcaps -> results/summary.md (no internet needed)
make test       # 4 small checks of the manifest and scripts
```
To add a test: add one entry to `captures/manifest.json` and one explanation file in `docs/tests/`. No code change is needed.
