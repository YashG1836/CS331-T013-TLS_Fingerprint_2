# Viva questions with short answers

Where the questions come from: what sir asked us in the Phase 1 eval (our WhatsApp list), the meeting transcript, and Implementation.md.
Learn the answers in your own words. Don't read them out.
"(our data: Tn)" means the answer is backed by our own test in `docs/tests/Tn_*.md`.

## A. Basics

1. **Why fingerprint at all?**
   The traffic is encrypted, so you can't read it. But the first message (ClientHello) is not encrypted, and each TLS library fills it differently: which ciphers, which extensions, in what order. So it tells you which software made the connection. Sir's example: a network wants to block a Firefox version with a vulnerability but allow Chrome.

2. **Why is the ClientHello plaintext?**
   It's the first message. No keys exist yet. The keys are made from the key share inside ClientHello and ServerHello (RFC 8446 §2).

3. **The data is unencrypted anyway, so why "fingerprint" it?**
   Each field alone means little. The combination and the order is what differs between libraries. Sir's analogy: same words, different way of speaking.

4. **ServerHello: isn't it always the same?**
   No. The server picks from what the client offered, so JA4S depends on the server **and** the client. Our data: the same Cloudflare server gave JA4S `..._1302_...` to curl and both `..._1301_...` and `..._1302_...` to Chromium (our data: T5, `results/summary.json`, field `ja4s_foxio`).

5. **TLS 1.2 vs 1.3?**
   - In TLS 1.3 everything after ServerHello is encrypted, including the certificate (RFC 8446 §2).
   - The real version sits in the `supported_versions` extension; the old version field stays 0x0303.
   - TLS 1.3 removed RSA key exchange, compression and renegotiation (RFC 8446 §1.2), and has 5 cipher suites (RFC 8446 Appendix B.4).
   - Effect for us: certificate fingerprints (JA4X) need the keys on TLS 1.3 (our data: T2).

6. **Where do the fields come from?**
   | Field | RFC |
   |---|---|
   | ciphers, extensions, versions | RFC 8446 §4.1.2 |
   | SNI | RFC 6066 §3 |
   | ALPN | RFC 7301 |
   | GREASE | RFC 8701 |
   | TCP options (JA4T) | RFC 9293 §3.1 |
   | QUIC Initial | RFC 9000 §17.2, RFC 9001 §5 |

7. **Why these fields and not others?**
   They are set by the software and stay the same between connections. Random fields (client random, session id, key share bytes) change every time, so they're left out.

8. **Hash length, and why hash?**
   - JA3 = MD5 of the field list, 32 hex characters.
   - JA4 = `a_b_c`, 36 characters. `a` is readable (protocol, version, SNI yes/no, number of ciphers, number of extensions, ALPN). `b` = first 12 hex of SHA-256 of the sorted ciphers. `c` = first 12 hex of SHA-256 of the sorted extensions + signature algorithms.
   - The hash is only a short key for lookup and sharing. It is not for security.

9. **Why not include the destination IP?**
   The fingerprint should describe the client software. The IP belongs to the server, and many websites can sit behind one IP (that's why SNI exists).

10. **Does it identify a user or an app?**
    It identifies a TLS library + its settings. curl and Python use the same OpenSSL and share JA4 part b, but differ in parts a and c (our data: T5). One app can also have many JA4s (our data: T5, Chromium).

11. **What is SNI?**
    The website name in the ClientHello, in plaintext (RFC 6066 §3). JA4 only records whether SNI is there (`d`) or not (`i`).

12. **eSNI / ECH?**
    eSNI was an older draft that encrypted only the SNI. It was replaced by ECH, which encrypts the whole real ClientHello with a key the server publishes in DNS (HTTPS record, RFC 9460). Outside, only a shared name is visible. Our data: the outer name was `cloudflare-ech.com`, and Cloudflare's page said `sni=encrypted` (T7).

13. **What is GREASE?**
    Random reserved values (0x0a0a, 0x1a1a, … 0xfafa, 16 of them, RFC 8701) that clients add so servers don't break on unknown values. Fingerprints must ignore them.

14. **Why does Chrome's JA3 change every time? Is JA4 stable?**
    Chromium changes the extension order on each connection (the first three hellos in our capture all have different orders), so we saw 50 different JA3s in 50 hellos. JA4 sorts the extensions to fix this. But with the released tools JA4 still gave 15 values, because Chromium puts a GREASE value in the signature algorithm list and the released tools don't remove it (our data: T5).

## B. Our method

15. **Why Python and not C/Rust? (asked in Phase 1)**
    This time we don't compute fingerprints at all. Wireshark/tshark (written in C) and FoxIO ja4 (written in Rust) do. Python only starts the tools and counts the results.

16. **Why not write your own?**
    Sir asked us to use the existing tools and find where they fail, because those tools are what people actually run.

17. **How do you know the output is correct?**
    - We run two tools on the same pcap and compare. They agreed on every capture.
    - But FoxIO's ja4 uses tshark to read packets (`rtshark` in its Cargo.toml), so they share one parser and are not fully independent.
    - Where they could be wrong, we checked FoxIO's own spec text and source code (T5).

18. **Performance? (asked in Phase 1)**
    On our small pcaps, tshark takes about 0.06 s and ja4 about 0.12 s per file (`seconds_*` columns in `results/summary.md`). We did not test big captures, so we don't claim anything more.

19. **Is your report AI-written?**
    Numbers come from `make eval`, not typed by hand. Our raw prompts are in `ai/prompts.txt`, unedited. `DECISIONS.md` will be written by us.

20. **Who keeps the fingerprint database up to date?**
    FoxIO keeps a mapping file (`ja4plus-mapping.csv` in their repo) and the ja4db.com site. Our T5 result shows why a database alone is risky: one browser gave 15 JA4s with the released tools.

## C. Limitations (our tests)

21. **QUIC: how can anyone decrypt the Initial packet?**
    Its keys come from a fixed public salt + the Destination Connection ID, which is in the packet (RFC 9001 §5.2). It stops tampering, not reading. Later packets use keys from the key exchange and can't be decrypted by a tap. Our data: both tools read all QUIC hellos (T1).

22. **Why remove header protection before decrypting?**
    The packet number is hidden by header protection, and the packet number is needed to build the decryption nonce (RFC 9001 §5.3, §5.4).

23. **Why join CRYPTO frames by offset?**
    The ClientHello can be split into many CRYPTO frames; arrival order isn't byte order (RFC 9000 §19.6). Our data: Chromium's QUIC hello came in 21 fragments (T1).

24. **Post-quantum key share: what changes?**
    Our data (T4):
    - The hello grew from 508 to 1511 bytes and needed 2 TCP segments at MTU 1500.
    - The server chose group 4588 (X25519MLKEM768).
    - JA4 has no group field but still changed: OpenSSL dropped `ec_point_formats` with PQ only, and added `padding` to the small hello.

25. **IPv6?**
    Not measured: our network has no IPv6 (T6). What we'd check: same JA4 expected (JA4 has no IP field); TCP MSS and IP-based attribution could change.

26. **Encrypted DNS?**
    It doesn't change the ClientHello; it hides the DNS lookup. Our data: with ECH on, the name was hidden in TLS but still visible in plain DNS (T7). Encrypted DNS was blocked on our campus network.

27. **GRO/GSO/TSO (sir's example from the other group)?**
    These let the kernel or network card join or split packets. Our data: the same ClientHello appeared as 1 frame of 1586 bytes or 2 frames, depending only on the offload setting (T3).

28. **Certificate compression / abridged certificates?**
    RFC 8879 compresses certificates; newer drafts replace them with shorter references. Then JA4X has less or nothing to read. We couldn't capture this; we only mention it.

29. **JA4X / JA4H on a normal tap?**
    Without keys: 0. With keys: 5 (our data: T2).

## D. Big picture

30. **Why isn't fingerprinting thrown away?**
    It needs no decryption and only one message, so it's cheap, and it worked on every capture we took. But our tests show it should be one signal, not proof: it changes with versions (T5), settings (T4) and ECH (T7).

31. **Its weaknesses (from our tests)?**
    - unstable with released tools (T5)
    - changes with crypto settings (T4)
    - certificate/HTTP parts need keys (T2)
    - TCP parts depend on where you capture (T3)
    - the website name disappears with ECH (T7)

32. **Alternatives?** (background reading, not tested by us)
    - other parts of the JA4+ family: JA4T (TCP), JA4H (HTTP), JA4X (certificate), JA4L (latency)
    - HTTP/2 fingerprinting
    - active probing of servers (JARM)
    - machine learning on packet sizes and timing

33. **What would make the technique useless?**
    If every client sent the same ClientHello (same library, same settings), it would carry no information.

34. **Can every number be regenerated?**
    Yes. `make eval` rebuilds `results/` from the committed pcaps. The few extra numbers (SYN values, GREASE counts) have their exact tshark command written in the test file.
