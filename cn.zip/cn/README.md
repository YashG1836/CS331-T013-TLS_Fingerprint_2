# Team T013 — Computer Networks Project 2

This repository is the implementation workspace for a reproducible study of practical TLS-fingerprinting limitations. The approved target is **seven evidence-backed limitations**. A claim is not a result until it is backed by a real capture, exact commands and versions, and a reproducible analysis.

## Current status

This workspace was created from the project documents because the earlier checkout contained documents only. The team-reported WSL run built the C++20 project, passed all 6 C++ tests and both Python tests, and validated the empty manifest. The WSL preflight also found the capture and dissection tools. `captures/manifest.json` still has no evidence records. No measured limitation, reference-tool comparison, fingerprint, or team decision is claimed. QUIC Initial decryption is specified by RFC 9001 and implemented in existing tools; it is not, by itself, the project-original contribution. L1 measures reference-tool coverage, not whether the ClientHello is unrecoverable.

## Layout

```text
code/quic/       C++20 QUIC v1 Initial parsing and extraction
code/scripts/    Python orchestration, manifest checks, and result generation
captures/        Empty evidence corpus and capture metadata schema
results/         Generated outputs; never hand-edit measurements
report/          Report source and generated report data
ppt/             Slides and source
ai/              Course-required records, only when actually created
docs/            RFC notes and project requirements
```

## Build and run

Requirements: C++20 compiler, CMake 3.20+, OpenSSL 3 development files, GoogleTest, Python 3.12, and GNU Make. TShark/dumpcap and the FoxIO JA4+ reference implementation are needed for the reference baseline, not for local parser builds.

```sh
make preflight
make build
make test
make check
make eval
```

The extractor currently accepts a single UDP datagram as hexadecimal bytes. It is not a pcap reader. It supports QUIC v1 client Initial packets only; do not infer Retry, QUIC v2, migration, 0-RTT, or server Initial support. QUIC JA4 is not emitted until the construction is verified against the current specification and an independent reference.

## First baseline experiment

Capture real QUIC v1 traffic, then run the pinned FoxIO JA4+ tool and TShark on the same capture. Record versions, commands, capture conditions, and whether each build exposes QUIC, JA3, and JA4 fields. Compare tool output with a recovered ClientHello only after the same bytes are identified. No capture or result is present yet.

See [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md), [docs/reading-guide.md](docs/reading-guide.md), [docs/baseline-procedure.md](docs/baseline-procedure.md), and [LEDGER.md](LEDGER.md).
