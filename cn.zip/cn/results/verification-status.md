# Verification and tool readiness

This log records the terminal output supplied by the team from Ubuntu WSL on 3 November 2026. It is a build/test and tool-readiness record, not network evidence.

## Build and tests

- `make test`: build completed; all 6 C++/GoogleTest cases passed; both Python `unittest` cases passed.
- `make check`: the initial run validated an empty manifest. After the baseline capture was added, `python3 code/scripts/manifest.py check captures/manifest.json` reported 1 evidence capture, marked provisional.
- A real QUIC v1 capture is present and registered provisionally. On frame 1, TShark 4.6.4 and FoxIO ja4 0.18.6 both report `q13d0307h3_55b375c5d22e_1cecd519fee8`; TShark also reports JA3 `121f6e4f22ee3205214b0676ed64b9e2`. The capture SHA-256 was rechecked as `1cd5f8c05b5b966eed1ae339eeec80b86b830deccda81489dabefb28f272ec7a`. The FoxIO executable SHA-256 is recorded in capture metadata. The exact dumpcap command/duration, client script/invocation, full FoxIO source provenance, and an independent byte-level ClientHello comparison remain missing. FoxIO calls system TShark, so the matching CLI outputs are not fully independent decoder evidence.

## WSL tools

`make preflight` reported Make, CMake, C++, OpenSSL, TShark, dumpcap, tcpdump, and Python available. The saved [`preflight.json`](preflight.json) records versions including GNU Make 4.4.1, CMake 4.2.3, GCC 15.2.0, OpenSSL 3.5.5, TShark/Wireshark 4.6.4, tcpdump 4.99.6, and Python 3.14.4. The build output separately reported GoogleTest 1.17.0.

The real capture's first frame is QUIC v1 Initial with CRYPTO offset 0, length 475, and a ClientHello. TShark reports a 523-byte QUIC packet in a 1200-byte UDP payload with 677 trailing zero bytes. The custom extractor fails on the full UDP payload (`QUIC fixed bit is zero`) but succeeds when given the 523-byte packet and recovers a complete 475-byte ClientHello. This is a custom-parser handling issue, not evidence that the ClientHello is unrecoverable or that the reference tools have an L1 coverage gap. The selected capture interface's permissions were not separately recorded.
