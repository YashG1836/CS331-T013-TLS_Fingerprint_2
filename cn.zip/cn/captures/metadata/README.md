# Capture metadata

Store one provenance record per capture here when evidence is collected. Record capture point, interface, direction, time, client and version, commands, tool versions, network conditions, and applicable RFC sections. No capture metadata is claimed yet.
