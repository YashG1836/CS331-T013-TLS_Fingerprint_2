# Packet captures

No evidence capture is present. Add only reviewed, consented captures with provenance and a matching record in `../manifest.json`. Do not commit public-session TLS key logs, credentials, personal browsing, or unrelated private data.
