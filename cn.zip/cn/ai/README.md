# AI-use records

No AI-use log is fabricated or backfilled here. Add records only from actual course-required logs and follow the team's submission rules.
