# Limitation ledger — evidence status

This is an evidence checklist. A real QUIC v1 capture and reference-tool outputs are now registered. L1 has a provisional baseline observation; its full evidence gate remains open pending exact capture/client commands and byte-level validation. L2-L7 remain open, and no project-original solution has been selected.

| ID | Hypothesis to test | Minimum evidence needed | Status |
|---|---|---|---|
| L1 | Pinned reference tools may differ in whether they expose QUIC v1 ClientHello and fingerprint fields. RFC 9001 Initial protection is recoverable from public inputs; a tool-coverage gap does not make the ClientHello unrecoverable. | Capture SHA-256 1cd5f8c05b5b966eed1ae339eeec80b86b830deccda81489dabefb28f272ec7a; TShark 4.6.4 and FoxIO JA4 0.18.6 both report q13d0307h3_55b375c5d22e_1cecd519fee8 for frame 1. Exact dumpcap command/duration, client script/invocation, full FoxIO source provenance, and independent ClientHello byte comparison are missing. FoxIO invokes system TShark, so the CLIs are not independent packet decoders. The custom CLI fails on the full datagram's 677 trailing zero bytes but succeeds on the 523-byte Initial packet. | Provisional baseline observed; full row open pending provenance and byte-level validation |
| L2 | JA4X/JA4H visibility depends on having the relevant TLS plaintext/secrets. | Same traffic and metadata with/without key log; outputs from the reference tools; exact tool versions. | Open — no capture |
| L3 | JA4T and packet-level observations depend on capture vantage point and network path. | Matched client/relay/proxy captures with interface, offload, NAT, MTU and tool metadata. | Open — no capture |
| L4 | Large hybrid key shares may affect ClientHello size and segmentation, but a negotiated key-exchange group and resulting fields must be verified before drawing conclusions. | Paired captures, negotiated group evidence, packet sizes/counts and fingerprint comparison. | Open — no capture |
| L5 | JA3 may vary across repeated handshakes while normalized JA4 may be more stable; applications sharing a TLS stack may collide. | Repeated captures per client plus two controlled applications, measured by scripts from committed evidence. | Open — no capture |
| L6 | IP family may leave TLS-only JA4 unchanged while affecting transport/correlation observations. | Matched IPv4/IPv6 captures, addresses and capture conditions, regenerated fingerprints. | Open — no capture |
| L7 | ECH and encrypted DNS may reduce hostname attribution; they must not be described as changing a TLS fingerprint unless the capture proves that. | Genuine supported ECH traffic or explicitly labelled simulation; DNS condition, tool output and attribution analysis. | Open — no capture |

Certificate compression/abridging remains a forward-looking watch item unless real deployed traffic is captured. A simulation must never be labelled as an observed network result.
