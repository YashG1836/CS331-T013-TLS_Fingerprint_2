# QUIC v1 reference-tool baseline

## Readiness snapshot

The WSL `make preflight` output supplied by the team on 3 November 2026 records:

- TShark/Wireshark 4.6.4; OpenSSL 3.5.5; GNU Make 4.4.1; CMake 4.2.3; GCC 15.2.0; Python 3.14.4; tcpdump 4.99.6.
- TShark's field registry includes `quic.version`, `quic.long.packet_type`, `quic.dcid`, `quic.crypto.offset`, `quic.crypto.length`, `quic.crypto.crypto_data`, `tls.handshake.ja3`, `tls.handshake.ja4`, and `tls.handshake.ja4_r`.
- `dumpcap -D` lists `eth0`, `any`, `lo`, Docker bridges/veth interfaces, and other virtual interfaces.
- The snapshot does **not** establish that TShark emits a ClientHello/JA3/JA4 for an actual QUIC capture, nor that `dumpcap` can open the selected interface for capture. No pcap is present yet.

This is tool-readiness evidence, not a measured L1 result.

## Pin the reference tool

Use the official FoxIO Rust JA4+ release **v1.0.1** as the initial reference candidate and record its exact executable version and SHA-256 when installed. The official release page shows v1.0.1 at commit `896b951`; its Rust CLI accepts `--json <pcap>`. It requires TShark 4.0.6 or newer, which the recorded 4.6.4 build satisfies. [FoxIO releases](https://github.com/FoxIO-LLC/ja4/releases), [Rust CLI usage](https://github.com/FoxIO-LLC/ja4/tree/main/rust).

Because FoxIO's Rust CLI depends on TShark, treat FoxIO and TShark as distinct fingerprinting paths with a shared dissection dependency—not as fully independent parsers. The same-capture comparison is still useful, but that dependency must be disclosed.

The WSL preflight currently reports `ja4` missing. On x86_64 WSL, first list the assets attached to the pinned release (this avoids guessing the archive URL):

```sh
uname -m
curl -fsSL https://api.github.com/repos/FoxIO-LLC/ja4/releases/tags/v1.0.1 \
  | python3 -c 'import json,sys; r=json.load(sys.stdin); [print(a["name"], a["browser_download_url"]) for a in r["assets"]]'
```

Download the official `ja4-v1.0.1` Linux x86_64 Rust archive shown in that list, then inspect and extract it locally (no system-wide installation is needed):

```sh
mkdir -p /tmp/foxio-ja4-v1.0.1
curl -fL '<official Linux x86_64 asset URL from the list>' -o /tmp/foxio-ja4-v1.0.1/ja4.tar.gz
sha256sum /tmp/foxio-ja4-v1.0.1/ja4.tar.gz
tar -tzf /tmp/foxio-ja4-v1.0.1/ja4.tar.gz
tar -xzf /tmp/foxio-ja4-v1.0.1/ja4.tar.gz -C /tmp/foxio-ja4-v1.0.1
find /tmp/foxio-ja4-v1.0.1 -type f -name ja4 -print
```

Use the executable path printed by `find` below; record its version and binary hash:

```sh
<path-to-ja4-binary> --version
sha256sum <path-to-ja4-binary>
tshark --version | head -n 1
```

Add the binary's directory to `PATH` before rerunning `make preflight` so the generated readiness record captures the JA4 version:

```sh
export PATH="$(dirname '<path-to-ja4-binary>'):$PATH"
make preflight
```

Do not use an unpinned `main` checkout as the reported baseline.

## Confirm the capture interface

The preflight lists several interfaces; determine the route and test capture access locally before recording evidence:

```sh
ip route get 1.1.1.1
dumpcap -D
dumpcap -i eth0 -a duration:1 -w /dev/null
```

The last command performs a one-second live capture without saving packet contents. Use the routed interface shown by `ip route get` in place of `eth0` if different. If it reports a permissions error, rerun with `sudo` and record that fact. Interface enumeration alone is not a permissions test.

## Controlled capture recipe

Check that the installed curl supports HTTP/3 before using it. `--http3-only` fails instead of silently falling back to TCP when QUIC cannot be established. [curl manual](https://curl.se/docs/manpage.html).

```sh
curl -V
curl --http3-only --max-time 15 -sS -o /dev/null \
  -w 'http_version=%{http_version} remote_ip=%{remote_ip}\n' \
  https://www.cloudflare.com/cdn-cgi/trace
```

Proceed only if curl reports HTTP/3 support and the request reports HTTP version `3`. Run one controlled request while capturing the routed WSL interface. Keep unrelated browsing and applications idle during the short capture window:

```sh
mkdir -p captures/pcaps
sudo dumpcap -i eth0 -f 'udp port 443' -a duration:20 \
  -w captures/pcaps/quic-v1-baseline.pcapng
```

Start the capture command, then immediately run the controlled `curl --http3-only` request in a second WSL shell. Use the actual routed interface instead of `eth0` if necessary. Record curl's exact version, command, reported HTTP version, server address, capture interface, and capture time in metadata. The command above can include other UDP/443 packets occurring during its 20-second window; review the capture before committing it. Do not add TLS key logs.

## Analyze the same capture bytes

First record the exact capture hash and tool versions. Then collect TShark fields and FoxIO JSON from the same pcap:

```sh
sha256sum captures/pcaps/quic-v1-baseline.pcapng
tshark --version | head -n 1
tshark -r captures/pcaps/quic-v1-baseline.pcapng \
  -Y 'quic || tls.handshake.type == 1' -T fields \
  -E header=y -E separator=$'\t' -E occurrence=a -E aggregator=, \
  -e frame.number -e quic.version -e quic.long.packet_type -e quic.dcid \
  -e quic.crypto.offset -e quic.crypto.length -e tls.handshake.type \
  -e tls.handshake.ja3 -e tls.handshake.ja4
<path-to-ja4-binary> --json captures/pcaps/quic-v1-baseline.pcapng
```

Save the exact commands, stdout/stderr, versions, and capture metadata. Empty fields or a non-zero exit are observations to investigate, not proof that QUIC Initial ClientHello recovery is impossible. Compare the recovered ClientHello bytes against a reference before interpreting a fingerprint. The custom CLI currently accepts hex for one UDP datagram and is not yet a pcap reader; do not claim whole-capture reassembly from it.
