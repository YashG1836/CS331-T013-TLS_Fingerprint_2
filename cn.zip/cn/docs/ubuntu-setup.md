# Ubuntu / WSL setup and first verification

The Windows sandbox reported `Wsl/E_ACCESS_DENIED` for `wsl --list --quiet`; no Ubuntu distribution could be inspected or run from this session. These commands are therefore instructions for the repository owner to run in an Ubuntu WSL shell. They have not been run here.

On Ubuntu 24.04 or another release that provides the project's Python version:

```sh
sudo apt update
sudo apt install -y build-essential cmake libssl-dev libgtest-dev python3 python3-venv make tshark tcpdump
cd "/mnt/c/Users/Miloni/Desktop/Uni/Sem 5/cn"
python3 --version
cmake --version
openssl version
tshark --version
make preflight
make build
make test
make check
make eval
```

The `make test` target runs the C++ unit executable through CTest and the Python standard-library tests. OpenSSL 3 development headers and libraries are required for the C++ target. If Ubuntu's `python3` is older than 3.12, use a 3.12 environment before running the harness.

To inspect capture interfaces, use `dumpcap -D` (install `wireshark-common` if needed). Capture only a controlled, consented test session; record the selected interface, exact command, tool versions, capture point, and network conditions in the metadata before treating the pcap as evidence. Do not commit public-session TLS key logs or credentials.

The first reference baseline must use one real QUIC v1 pcap as input to both a pinned FoxIO JA4+ release and TShark. Record exact invocations and inspect field support with `tshark -G fields`. The FoxIO command is intentionally not guessed here: select and pin a concrete release/interface before recording it. Compare the two outputs and the extractor on identical capture bytes. No capture should be synthesized to fill the empty manifest.
