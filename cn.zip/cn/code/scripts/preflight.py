"""Collect local tool readiness; this records availability, not experiment results."""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
TOOLS = {
    "make": ["--version"], "cmake": ["--version"], "c++": ["--version"],
    "openssl": ["version"], "tshark": ["--version"], "ja4": ["--version"],
    "dumpcap": ["-D"], "tcpdump": ["--version"],
}


def run(executable: str, args: list[str]) -> dict:
    path = shutil.which(executable)
    if not path:
        return {"available": False}
    try:
        proc = subprocess.run([path, *args], capture_output=True, text=True, timeout=12, check=False)
        output = (proc.stdout + proc.stderr).strip()
        return {"available": True, "path": path, "exit_code": proc.returncode,
                "output": output[:6000]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": True, "path": path, "error": str(exc)}


def main() -> int:
    report = {"tools": {name: run(name, args) for name, args in TOOLS.items()},
              "checked_at_utc": datetime.now(timezone.utc).isoformat(),
              "capture_permission": "not independently verified; inspect dumpcap interfaces and OS permissions",
              "tshark_fields": {"available": False, "quic": [], "ja3": [], "ja4": []}}
    try:
        proc = subprocess.run([sys.executable, "--version"], capture_output=True, text=True, timeout=12, check=False)
        report["tools"]["python"] = {"available": proc.returncode == 0, "path": sys.executable,
                                      "exit_code": proc.returncode, "output": (proc.stdout + proc.stderr).strip()}
    except (OSError, subprocess.TimeoutExpired) as exc:
        report["tools"]["python"] = {"available": False, "path": sys.executable, "error": str(exc)}
    tshark = report["tools"]["tshark"]
    if tshark.get("available"):
        p = subprocess.run([tshark["path"], "-G", "fields"], capture_output=True, text=True, timeout=30, check=False)
        field_names = set()
        for line in p.stdout.splitlines():
            columns = line.split("\t")
            if len(columns) >= 3 and columns[0] == "F":
                field_names.add(columns[2])
        report["tshark_fields"] = {"available": p.returncode == 0,
            "quic": sorted(x for x in field_names if x.startswith("quic.")),
            "ja3": sorted(x for x in field_names if "ja3" in x.lower()),
            "ja4": sorted(x for x in field_names if "ja4" in x.lower()),
        }
        report["tshark_fields_exit_code"] = p.returncode
    out = ROOT / "results" / "preflight.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    for name, value in report["tools"].items():
        status = "available" if value.get("available") else "missing"
        print(f"{name}: {status}")
    print(f"Wrote {out.relative_to(ROOT)}. Capture permission is not inferred from tool presence.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
