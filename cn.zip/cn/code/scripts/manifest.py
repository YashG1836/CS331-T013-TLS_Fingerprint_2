"""Validate capture evidence metadata without inventing observations."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys


def validate(path: Path, root: Path | None = None) -> list[str]:
    errors: list[str] = []
    root = (root or path.parent.parent).resolve()
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot read manifest: {exc}"]
    if not isinstance(obj, dict) or obj.get("schema_version") != 1:
        return ["manifest must be an object with schema_version=1"]
    captures = obj.get("captures")
    if not isinstance(captures, list):
        return ["captures must be a list"]
    if not captures and obj.get("status") != "no_evidence_yet":
        errors.append("an empty corpus must use status=no_evidence_yet")
    ids: set[str] = set()
    required = {"id", "scenario", "capture", "protocol", "client", "commands", "tool_versions", "conditions"}
    for i, rec in enumerate(captures):
        label = f"captures[{i}]"
        if not isinstance(rec, dict):
            errors.append(f"{label} must be an object")
            continue
        missing = required - rec.keys()
        if missing:
            errors.append(f"{label} missing fields: {', '.join(sorted(missing))}")
            continue
        rid = rec["id"]
        if not isinstance(rid, str) or not rid.strip():
            errors.append(f"{label}.id must be a non-empty string")
        elif rid in ids:
            errors.append(f"duplicate capture id: {rid}")
        else:
            ids.add(rid)
        if not isinstance(rec["commands"], list) or not rec["commands"]:
            errors.append(f"{label}.commands must be a non-empty list of exact commands")
        if not isinstance(rec["tool_versions"], dict) or not rec["tool_versions"]:
            errors.append(f"{label}.tool_versions must record actual versions")
        if not isinstance(rec["conditions"], dict) or not rec["conditions"]:
            errors.append(f"{label}.conditions must record capture conditions")
        rel = rec["capture"]
        if not isinstance(rel, str):
            errors.append(f"{label}.capture must be a relative path")
            continue
        resolved = (root / rel).resolve()
        if root not in resolved.parents:
            errors.append(f"{label}.capture escapes the repository root")
        elif not resolved.is_file():
            errors.append(f"{label}.capture does not exist: {rel}")
    pcap_dir = root / "captures" / "pcaps"
    if pcap_dir.exists():
        registered = {
            (root / rec["capture"]).resolve()
            for rec in captures
            if isinstance(rec, dict) and isinstance(rec.get("capture"), str)
        }
        for candidate in pcap_dir.rglob("*"):
            if candidate.is_file() and candidate.suffix.lower() in {".pcap", ".pcapng"}:
                if candidate.resolve() not in registered:
                    errors.append(f"unregistered evidence capture file: {candidate.relative_to(root).as_posix()}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["check"])
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    errors = validate(args.manifest)
    if errors:
        print("Manifest invalid:")
        for error in errors:
            print(f"- {error}")
        return 1
    data = json.loads(args.manifest.read_text(encoding="utf-8"))
    print(f"Manifest valid: {len(data['captures'])} evidence capture(s)")
    if not data["captures"]:
        print("status=no_evidence_yet; no measurement is claimed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
