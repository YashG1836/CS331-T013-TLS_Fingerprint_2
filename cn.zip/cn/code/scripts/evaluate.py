"""Emit an explicit no-evidence status until captures are supplied."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from manifest import validate


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    errors = validate(args.manifest)
    if errors:
        print("Manifest invalid: " + "; ".join(errors), file=sys.stderr)
        return 1
    obj = json.loads(args.manifest.read_text(encoding="utf-8"))
    result = {"status": "no_evidence_yet" if not obj["captures"] else "evidence_registered_not_evaluated",
              "capture_count": len(obj["captures"]), "limitations": {f"L{i}": "open_no_evidence" for i in range(1, 8)},
              "measurements": []}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
