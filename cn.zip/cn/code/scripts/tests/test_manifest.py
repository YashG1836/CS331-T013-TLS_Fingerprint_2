import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from manifest import validate


class ManifestTests(unittest.TestCase):
    def test_empty_evidence_is_explicit(self):
        workspace = Path(__file__).resolve().parents[3]
        with tempfile.TemporaryDirectory(dir=workspace) as d:
            root = Path(d)
            p = root / "manifest.json"
            p.write_text(json.dumps({"schema_version": 1, "status": "no_evidence_yet", "captures": []}))
            self.assertEqual(validate(p, root), [])

    def test_rejects_duplicate_ids_and_missing_capture(self):
        workspace = Path(__file__).resolve().parents[3]
        with tempfile.TemporaryDirectory(dir=workspace) as d:
            root = Path(d)
            record = {"id": "x", "scenario": "L1", "capture": "captures/x.pcap", "protocol": "quic-v1",
                      "client": "unknown", "commands": ["actual command"], "tool_versions": {"tool": "actual version"},
                      "conditions": {"capture": "actual conditions"}}
            p = root / "manifest.json"
            p.write_text(json.dumps({"schema_version": 1, "captures": [record, record]}))
            errors = validate(p, root)
            self.assertTrue(any("duplicate capture id" in e for e in errors))
            self.assertTrue(any("does not exist" in e for e in errors))


if __name__ == "__main__":
    unittest.main()
