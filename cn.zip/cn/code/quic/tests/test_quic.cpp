#include "quic/quic.hpp"

#include <gtest/gtest.h>

TEST(Varint, DecodesAndRejectsTruncation) {
  quic::Bytes one{0x40,0x25};std::size_t p=0;
  EXPECT_EQ(quic::read_varint(one,p),37U);
  quic::Bytes two{0x7b,0xbd};p=0;
  EXPECT_EQ(quic::read_varint(two,p),15293U);
  quic::Bytes short_value{0x40};p=0;
  EXPECT_THROW((void)quic::read_varint(short_value,p),std::runtime_error);
}

TEST(InitialKeys, MatchesRfc9001AppendixA1) {
  const auto dcid=quic::unhex("8394c8f03e515708");
  const auto keys=quic::derive_client_initial_key(dcid);
  EXPECT_EQ(quic::hex(keys),"1f369613dd76d5467730efcbe3b1a22dfa044b2f42a3fd3b46fb255c9f50449e04a0e810283a1e9933adedd2");
}

TEST(CryptoReassembly, HandlesOrderDuplicatesGapsAndConflicts) {
  quic::CryptoReassembler r;
  const auto tail=quic::unhex("4344"),head=quic::unhex("4142");
  r.insert(2,tail);r.insert(0,head);r.insert(1,quic::unhex("42"));
  EXPECT_EQ(quic::hex(r.contiguous()),"41424344");
  EXPECT_THROW(r.insert(1,quic::unhex("ff")),std::runtime_error);
  quic::CryptoReassembler gap;gap.insert(2,tail);
  EXPECT_TRUE(gap.contiguous().empty());
}

TEST(ClientHello, ValidatesStructureAndRejectsTruncation) {
  quic::Bytes hello{1,0,0,43,3,3};hello.insert(hello.end(),32,0);
  hello.insert(hello.end(),{0,0,2,0,0x2f,1,0,0,0});
  EXPECT_NO_THROW(quic::validate_client_hello(hello));
  hello.pop_back();
  EXPECT_THROW(quic::validate_client_hello(hello),std::runtime_error);
}

TEST(Datagram, PreservesCoalescedLongAndFinalShortPacketBoundaries) {
  const auto datagram=quic::unhex("c00000000101aa01bb000100e00000000101aa01bb010040aabb");
  const auto packets=quic::parse_datagram(datagram);
  ASSERT_EQ(packets.size(),3U);
  EXPECT_EQ(packets[0].type,0U);
  EXPECT_EQ(packets[0].packet_length,12U);
  EXPECT_EQ(packets[1].type,2U);
  EXPECT_EQ(packets[1].packet_offset,packets[0].packet_length);
  EXPECT_EQ(packets[2].type,4U);
  EXPECT_EQ(packets[2].packet_offset+packets[2].packet_length,datagram.size());
}

TEST(Datagram, RejectsTruncatedHeader) {
  EXPECT_THROW((void)quic::parse_datagram(quic::unhex("c0")),std::runtime_error);
}
