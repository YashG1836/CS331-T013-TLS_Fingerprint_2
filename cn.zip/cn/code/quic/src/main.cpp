#include "quic/quic.hpp"

#include <iostream>
#include <stdexcept>

int main(int argc,char** argv) {
  try {
    if(argc!=3 || std::string(argv[1])!="--hex") {
      std::cerr << "usage: quic-fingerprint --hex <one-UDP-datagram-as-hex>\n";
      return 2;
    }
    const auto datagram=quic::unhex(argv[2]);
    const auto packets=quic::parse_datagram(datagram);
    quic::CryptoReassembler reassembly;
    std::size_t initial_count=0;
    const quic::Packet* first_initial=nullptr;
    for(const auto& packet:packets) if(packet.type==0) { first_initial=&packet; break; }
    for(const auto& packet:packets) {
      if(packet.type!=0) continue;
      if(first_initial==nullptr) throw std::runtime_error("no Initial packet found");
      ++initial_count;
      const auto plain=quic::decrypt_client_initial(datagram,packet,first_initial->dcid);
      for(const auto& frame:quic::parse_initial_frames(plain)) reassembly.insert(frame.offset,frame.data);
    }
    std::cout << "quic_version=1 packets=" << packets.size() << " client_initial_packets=" << initial_count << '\n';
    const auto handshake=reassembly.contiguous();
    if(handshake.size()<4) { std::cout << "client_hello=incomplete_crypto_data bytes=" << handshake.size() << '\n'; return 0; }
    const auto n=quic::client_hello_length(handshake);
    if(handshake.size()<n) { std::cout << "client_hello=incomplete bytes=" << handshake.size() << " expected=" << n << '\n'; return 0; }
    quic::validate_client_hello(std::span<const std::uint8_t>(handshake).first(n));
    std::cout << "client_hello=complete bytes=" << n << " handshake_hex=" << quic::hex(std::span<const std::uint8_t>(handshake).first(n)) << '\n';
    return 0;
  } catch(const std::exception& e) {
    std::cerr << "error: " << e.what() << '\n'; return 1;
  }
}
