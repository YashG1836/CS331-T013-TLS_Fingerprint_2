#include "quic/quic.hpp"

#include <openssl/core_names.h>
#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/params.h>

#include <algorithm>
#include <array>
#include <limits>
#include <memory>
#include <stdexcept>

namespace quic {
namespace {
using Ctx = std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)>;
using Kdf = std::unique_ptr<EVP_KDF, decltype(&EVP_KDF_free)>;
using KdfCtx = std::unique_ptr<EVP_KDF_CTX, decltype(&EVP_KDF_CTX_free)>;
constexpr std::uint32_t kVersion1 = 0x00000001;
constexpr std::array<std::uint8_t, 20> kSalt{
  0x38,0x76,0x2c,0xf7,0xf5,0x59,0x34,0xb3,0x4d,0x17,
  0x9a,0xe6,0xa4,0xc8,0x0c,0xad,0xcc,0xbb,0x7f,0x0a};

void need(std::span<const std::uint8_t> b, std::size_t p, std::size_t n) {
  if (p > b.size() || n > b.size() - p) throw std::runtime_error("truncated QUIC data");
}
std::uint64_t read_n(std::span<const std::uint8_t> b, std::size_t& p, std::size_t n) {
  need(b,p,n); std::uint64_t v=0;
  for (std::size_t i=0;i<n;i++) v=(v<<8U)|b[p++];
  return v;
}
Bytes hkdf(std::span<const std::uint8_t> key, std::span<const std::uint8_t> salt,
           std::span<const std::uint8_t> info, std::size_t out_len, bool extract_only=false) {
  Kdf k(EVP_KDF_fetch(nullptr,"HKDF",nullptr), EVP_KDF_free);
  if (!k) throw std::runtime_error("OpenSSL HKDF unavailable");
  KdfCtx c(EVP_KDF_CTX_new(k.get()), EVP_KDF_CTX_free);
  if (!c) throw std::runtime_error("OpenSSL HKDF context allocation failed");
  char digest[]="SHA256";
  int mode=extract_only ? EVP_KDF_HKDF_MODE_EXTRACT_ONLY : EVP_KDF_HKDF_MODE_EXPAND_ONLY;
  OSSL_PARAM params[5];
  params[0]=OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST,digest,0);
  params[1]=OSSL_PARAM_construct_int(OSSL_KDF_PARAM_MODE,&mode);
  params[2]=OSSL_PARAM_construct_octet_string(extract_only ? OSSL_KDF_PARAM_KEY : OSSL_KDF_PARAM_KEY,
                                               const_cast<std::uint8_t*>(key.data()),key.size());
  params[3]=OSSL_PARAM_construct_octet_string(extract_only ? OSSL_KDF_PARAM_SALT : OSSL_KDF_PARAM_INFO,
                                               const_cast<std::uint8_t*>(extract_only ? salt.data() : info.data()),
                                               extract_only ? salt.size() : info.size());
  params[4]=OSSL_PARAM_construct_end();
  Bytes out(out_len);
  if (EVP_KDF_derive(c.get(),out.data(),out.size(),params)!=1) throw std::runtime_error("OpenSSL HKDF derive failed");
  return out;
}
Bytes label_expand(std::span<const std::uint8_t> secret, const std::string& label, std::size_t n) {
  const std::string full="tls13 "+label;
  if (n>65535 || full.size()>255) throw std::runtime_error("HKDF label too long");
  // HkdfLabel = uint16(output length) || opaque label<7..255> || opaque context<0..255>.
  Bytes info{static_cast<std::uint8_t>((n >> 8U) & 0xffU),
             static_cast<std::uint8_t>(n & 0xffU),
             static_cast<std::uint8_t>(full.size())};
  info.insert(info.end(),full.begin(),full.end()); info.push_back(0);
  return hkdf(secret,{},info,n);
}
Bytes initial_secret(std::span<const std::uint8_t> dcid) { return hkdf(dcid,kSalt,{},32,true); }
struct KeySet { Bytes key,iv,hp; };
KeySet client_keys(std::span<const std::uint8_t> dcid) {
  auto initial=initial_secret(dcid);
  static constexpr std::array<std::uint8_t,0> empty{};
  auto client=label_expand(initial,"client in",32);
  (void)empty;
  return {label_expand(client,"quic key",16),label_expand(client,"quic iv",12),label_expand(client,"quic hp",16)};
}
std::uint64_t packet_number(std::uint64_t truncated,unsigned bits,std::uint64_t expected) {
  const std::uint64_t window=std::uint64_t{1}<<bits, half=window/2, mask=window-1;
  std::uint64_t candidate=(expected&~mask)|truncated;
  if (candidate+half<=expected && candidate<=((std::uint64_t{1}<<62U)-window)) candidate+=window;
  else if (candidate>expected+half && candidate>=window) candidate-=window;
  return candidate;
}
Bytes aes_block(std::span<const std::uint8_t> key,std::span<const std::uint8_t> sample) {
  if(sample.size()<16) throw std::runtime_error("short header-protection sample");
  Ctx c(EVP_CIPHER_CTX_new(),EVP_CIPHER_CTX_free); Bytes out(16); int n=0,tail=0;
  if(!c || EVP_EncryptInit_ex(c.get(),EVP_aes_128_ecb(),nullptr,key.data(),nullptr)!=1 ||
     EVP_CIPHER_CTX_set_padding(c.get(),0)!=1 || EVP_EncryptUpdate(c.get(),out.data(),&n,sample.data(),16)!=1 ||
     EVP_EncryptFinal_ex(c.get(),out.data()+n,&tail)!=1) throw std::runtime_error("AES header protection failed");
  return out;
}
Bytes gcm_decrypt(std::span<const std::uint8_t> key,std::span<const std::uint8_t> nonce,
                  std::span<const std::uint8_t> aad,std::span<const std::uint8_t> cipher) {
  if(cipher.size()<16) throw std::runtime_error("Initial ciphertext shorter than tag");
  Ctx c(EVP_CIPHER_CTX_new(),EVP_CIPHER_CTX_free); Bytes out(cipher.size()-16); int n=0,total=0;
  if(!c || EVP_DecryptInit_ex(c.get(),EVP_aes_128_gcm(),nullptr,nullptr,nullptr)!=1 ||
     EVP_CIPHER_CTX_ctrl(c.get(),EVP_CTRL_GCM_SET_IVLEN,static_cast<int>(nonce.size()),nullptr)!=1 ||
     EVP_DecryptInit_ex(c.get(),nullptr,nullptr,key.data(),nonce.data())!=1 ||
     EVP_DecryptUpdate(c.get(),nullptr,&n,aad.data(),static_cast<int>(aad.size()))!=1 ||
     EVP_DecryptUpdate(c.get(),out.data(),&n,cipher.data(),static_cast<int>(out.size()))!=1)
    throw std::runtime_error("AES-GCM decryption setup failed");
  total=n;
  auto* tag=const_cast<std::uint8_t*>(cipher.data()+out.size());
  if(EVP_CIPHER_CTX_ctrl(c.get(),EVP_CTRL_GCM_SET_TAG,16,tag)!=1 || EVP_DecryptFinal_ex(c.get(),out.data()+total,&n)!=1)
    throw std::runtime_error("Initial authentication failed");
  out.resize(static_cast<std::size_t>(total+n)); return out;
}
void skip_ack(std::span<const std::uint8_t> b,std::size_t& p,bool ecn) {
  (void)read_varint(b,p); (void)read_varint(b,p); (void)read_varint(b,p);
  auto ranges=read_varint(b,p); (void)read_varint(b,p);
  if(ranges>100000) throw std::runtime_error("ACK range count exceeds limit");
  for(std::uint64_t i=0;i<ranges;i++){(void)read_varint(b,p);(void)read_varint(b,p);}
  if(ecn) for(int i=0;i<3;i++) (void)read_varint(b,p);
}
}

std::uint64_t read_varint(std::span<const std::uint8_t> b,std::size_t& p) {
  need(b,p,1); const std::size_t n=std::size_t{1}<<((b[p]>>6U)&3U);
  std::uint64_t v=b[p++]&0x3fU; need(b,p,n-1);
  for (std::size_t i = 1; i < n; i++) {
    v = (v << 8U) | b[p++];
  }
  return v;
}
std::vector<Packet> parse_datagram(std::span<const std::uint8_t> b) {
  std::vector<Packet> out; std::size_t p=0;
  while(p<b.size()) {
    const std::size_t start=p; need(b,p,1);
    const std::uint8_t first=b[p++];
    if((first&0x80U)==0) {
      if((first&0x40U)==0) throw std::runtime_error("QUIC fixed bit is zero");
      // A short-header packet has no explicit length and must be last in a datagram.
      out.push_back(Packet{0,4,{}, {}, {}, start, b.size()-start, start+1});
      p=b.size();
      break;
    }
    need(b,p,5); const auto version=static_cast<std::uint32_t>(read_n(b,p,4));
    if(version!=kVersion1) throw std::runtime_error("unsupported QUIC version (only v1)");
    const std::uint8_t type=static_cast<std::uint8_t>((first>>4U)&3U);
    if(type==3) throw std::runtime_error("Retry packets are not supported");
    const auto dl=static_cast<std::size_t>(read_n(b,p,1)); if(dl>20) throw std::runtime_error("invalid destination CID length");
    need(b,p,dl+1); Bytes dcid(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+dl)); p+=dl;
    const auto sl=static_cast<std::size_t>(read_n(b,p,1)); if(sl>20) throw std::runtime_error("invalid source CID length");
    need(b,p,sl); Bytes scid(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+sl)); p+=sl;
    Bytes token;
    if(type==0) { const auto tl=read_varint(b,p); if(tl>b.size()-p) throw std::runtime_error("truncated Initial token");
      token.assign(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+tl)); p+=static_cast<std::size_t>(tl); }
    const auto len=read_varint(b,p); if(len>b.size()-p) throw std::runtime_error("truncated QUIC packet payload");
    const auto plen=static_cast<std::size_t>(len); const auto end=p+plen;
    out.push_back(Packet{version,type,std::move(dcid),std::move(scid),std::move(token),start,end-start,p}); p=end;
    if((first&0x40U)==0) throw std::runtime_error("QUIC fixed bit is zero");
  }
  return out;
}
Bytes derive_client_initial_key(std::span<const std::uint8_t> dcid) {
  const auto k=client_keys(dcid); Bytes out=k.key; out.insert(out.end(),k.iv.begin(),k.iv.end()); out.insert(out.end(),k.hp.begin(),k.hp.end()); return out;
}
Bytes decrypt_client_initial(std::span<const std::uint8_t> d,const Packet& packet,std::span<const std::uint8_t> odcid) {
  if(packet.type!=0) throw std::runtime_error("packet is not an Initial");
  if(!packet.token.empty()) throw std::runtime_error("Initial token after Retry is outside supported scope");
  const auto end=packet.packet_offset+packet.packet_length; need(d,packet.pn_offset,20);
  if(end>d.size() || packet.pn_offset+20>end) throw std::runtime_error("packet too short for header protection sample");
  const auto keys=client_keys(odcid); auto mask=aes_block(keys.hp,d.subspan(packet.pn_offset+4,16));
  Bytes header(d.begin()+static_cast<std::ptrdiff_t>(packet.packet_offset),d.begin()+static_cast<std::ptrdiff_t>(packet.pn_offset));
  header[0]^=static_cast<std::uint8_t>(mask[0]&0x0fU); const auto pnlen=static_cast<std::size_t>((header[0]&3U)+1U);
  if(packet.pn_offset+pnlen>end) throw std::runtime_error("truncated packet number");
  std::uint64_t trunc=0; for(std::size_t i=0;i<pnlen;i++){const auto v=static_cast<std::uint8_t>(d[packet.pn_offset+i]^mask[i+1]);header.push_back(v);trunc=(trunc<<8U)|v;}
  const auto pn=packet_number(trunc,static_cast<unsigned>(pnlen*8),0);
  Bytes nonce=keys.iv; for(std::size_t i=0;i<8;i++) nonce[nonce.size()-1-i]^=static_cast<std::uint8_t>(pn>>(8U*i));
  return gcm_decrypt(keys.key,nonce,header,d.subspan(packet.pn_offset+pnlen,end-(packet.pn_offset+pnlen)));
}
std::vector<CryptoFrame> parse_initial_frames(std::span<const std::uint8_t> b) {
  std::vector<CryptoFrame> frames; std::size_t p=0;
  while(p<b.size()) { const auto t=read_varint(b,p);
    if(t==0) continue;
    if(t==1) continue;
    if(t==2 || t==3) { skip_ack(b,p,t==3); continue; }
    if(t==6) { const auto off=read_varint(b,p), n=read_varint(b,p); if(n>b.size()-p) throw std::runtime_error("truncated CRYPTO frame");
      Bytes data(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+n));p+=static_cast<std::size_t>(n);frames.push_back({off,std::move(data)});continue; }
    if(t==0x1c || t==0x1d) { (void)read_varint(b,p); if(t==0x1c) (void)read_varint(b,p); const auto n=read_varint(b,p); if(n>b.size()-p) throw std::runtime_error("truncated CONNECTION_CLOSE reason");p+=static_cast<std::size_t>(n);continue; }
    throw std::runtime_error("unsupported frame type in Initial packet");
  }
  return frames;
}
void CryptoReassembler::insert(std::uint64_t off,std::span<const std::uint8_t> data) {
  if(off>limit_ || data.size()>limit_-static_cast<std::size_t>(off)) throw std::runtime_error("CRYPTO data exceeds configured limit");
  for(std::size_t i=0;i<data.size();i++){const auto pos=off+i;auto it=bytes_.find(pos);if(it!=bytes_.end()&&it->second!=data[i])throw std::runtime_error("conflicting CRYPTO overlap");bytes_[pos]=data[i];}
}
Bytes CryptoReassembler::contiguous() const { Bytes out; std::uint64_t i=0;for(const auto& [pos,b]:bytes_){if(pos!=i)break;out.push_back(b);++i;}return out; }
std::size_t client_hello_length(std::span<const std::uint8_t> b) {
  if(b.size()<4) throw std::runtime_error("incomplete TLS handshake header");
  if(b[0]!=1) throw std::runtime_error("first TLS handshake message is not ClientHello");
  const std::size_t body=(static_cast<std::size_t>(b[1])<<16U)|(static_cast<std::size_t>(b[2])<<8U)|b[3];
  if(body>std::numeric_limits<std::size_t>::max()-4) throw std::runtime_error("ClientHello length overflow");
  return body+4;
}
void validate_client_hello(std::span<const std::uint8_t> b) {
  const auto total=client_hello_length(b); if(b.size()<total) throw std::runtime_error("incomplete ClientHello");
  std::size_t p=4; auto take=[&](std::size_t n){need(b,p,n);p+=n;};
  take(2+32); need(b,p,1); const auto sid=b[p++]; take(sid);
  need(b,p,2); const auto cs=(static_cast<std::size_t>(b[p])<<8U)|b[p+1];p+=2;if(cs<2||(cs&1U))throw std::runtime_error("invalid cipher_suites vector");take(cs);
  need(b,p,1);const auto comp=b[p++];if(comp==0)throw std::runtime_error("empty compression_methods vector");take(comp);
  if(p==total)return;
  need(b,p,2);const auto ext=(static_cast<std::size_t>(b[p])<<8U)|b[p+1];p+=2;if(ext!=total-p)throw std::runtime_error("invalid extensions vector length");
  const auto end=p+ext;while(p<end){need(b,p,4);const auto n=(static_cast<std::size_t>(b[p+2])<<8U)|b[p+3];p+=4;if(n>end-p)throw std::runtime_error("truncated ClientHello extension");p+=n;}
}
std::string hex(std::span<const std::uint8_t> b){static constexpr char h[]="0123456789abcdef";std::string s;s.reserve(b.size()*2);for(auto v:b){s.push_back(h[v>>4U]);s.push_back(h[v&15U]);}return s;}
Bytes unhex(const std::string& s){if(s.size()%2)throw std::runtime_error("hex input has odd length");Bytes b;b.reserve(s.size()/2);for(std::size_t i=0;i<s.size();i+=2){auto cv=[](char c)->int{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};int a=cv(s[i]),z=cv(s[i+1]);if(a<0||z<0)throw std::runtime_error("invalid hex input");b.push_back(static_cast<std::uint8_t>((a<<4)|z));}return b;}
}  // namespace quic
