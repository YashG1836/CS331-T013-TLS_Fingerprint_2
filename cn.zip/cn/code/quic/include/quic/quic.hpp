#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <span>
#include <string>
#include <vector>

namespace quic {
using Bytes = std::vector<std::uint8_t>;

struct Packet {
  std::uint32_t version{};
  std::uint8_t type{};
  Bytes dcid;
  Bytes scid;
  Bytes token;
  std::size_t packet_offset{};
  std::size_t packet_length{};
  std::size_t pn_offset{};
};

struct CryptoFrame { std::uint64_t offset{}; Bytes data; };

std::uint64_t read_varint(std::span<const std::uint8_t> input, std::size_t& pos);
std::vector<Packet> parse_datagram(std::span<const std::uint8_t> datagram);
Bytes derive_client_initial_key(std::span<const std::uint8_t> original_dcid);
Bytes decrypt_client_initial(std::span<const std::uint8_t> datagram,
                             const Packet& packet,
                             std::span<const std::uint8_t> original_dcid);
std::vector<CryptoFrame> parse_initial_frames(std::span<const std::uint8_t> plaintext);

class CryptoReassembler {
 public:
  explicit CryptoReassembler(std::size_t limit = 1U << 20) : limit_(limit) {}
  void insert(std::uint64_t offset, std::span<const std::uint8_t> data);
  Bytes contiguous() const;
 private:
  std::size_t limit_;
  std::map<std::uint64_t, std::uint8_t> bytes_;
};

std::size_t client_hello_length(std::span<const std::uint8_t> handshake);
void validate_client_hello(std::span<const std::uint8_t> handshake);
std::string hex(std::span<const std::uint8_t> bytes);
Bytes unhex(const std::string& text);
}  // namespace quic
